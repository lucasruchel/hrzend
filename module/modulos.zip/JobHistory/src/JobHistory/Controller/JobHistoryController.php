<?php

namespace JobHistory\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use JobHistory\Model\JobHistory;        
use JobHistory\Form\JobHistoryForm;

class JobHistoryController extends AbstractActionController
{
    protected $jobHistoryTable= null;
    
    public function getJobHistoryTable(){
        if (!$this->jobHistoryTable){
            $sm =  $this->getServiceLocator();
            
            $this->jobHistoryTable = $sm->get('JobHistory\Model\JobHistoryTable');
        }
        
        return $this->jobHistoryTable;
    }
    protected function getViewHelper($helperName)
    {
        return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
    }

        public function indexAction()
        {
            $form = new JobHistoryForm();
            
            $renderer = $this->serviceLocator->get('Zend\View\Renderer\RendererInterface');

            $this->getViewHelper('HeadScript')->appendFile($renderer->basePath('/js/formTrigger.js'));
            
            $params = $this->params()->fromQuery();
            
            
            
            \Zend\Debug\Debug::dump($params);
            
            
            $paginator = $this->getJobHistoryTable()->fetchAll(true,$params);

            $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));

            $paginator->setItemCountPerPage(10);
            
            return new ViewModel(
                array(
                    'jobHistory' => $paginator,
                           'form' => $form,
                    )
            );
        }
        public function relatorioAction()
        {
            return new ViewModel();
           
        }
}

